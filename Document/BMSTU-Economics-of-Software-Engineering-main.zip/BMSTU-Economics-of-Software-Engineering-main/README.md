# BMSTU-Economics-of-Software-Engineering
BMSTU Economics of Software Engineering course 2021
